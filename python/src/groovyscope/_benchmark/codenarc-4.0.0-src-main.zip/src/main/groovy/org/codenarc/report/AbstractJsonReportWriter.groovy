/*
 * Copyright 2025 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.codenarc.report

import groovy.json.JsonOutput
import org.codenarc.AnalysisContext
import org.codenarc.results.Results

/**
 * Abstract superclass for JSON ReportWriter classes.
 */
abstract class AbstractJsonReportWriter extends AbstractReportWriter {

    Boolean writeAsSingleLine = false

    @Override
    void writeReport(Writer writer, AnalysisContext analysisContext, Results results) {
        assert analysisContext
        assert results

        initializeResourceBundle()

        def rootObject = buildJsonStructure(analysisContext, results)

        /*
           Append JSON to writer
           - isWriteAsSingleLine == true: writes result in a stdout single line
           - isWriteAsSingleLine == false: pretty print it for easier reading
         */
        def json = JsonOutput.toJson(rootObject)
        if (!isWriteAsSingleLine()) {
            json = JsonOutput.prettyPrint(json)
        }

        if (isWriteToStandardOut()) {
            def printWriter = new PrintWriter(writer)
            printWriter.println(json)
            printWriter.flush()
        } else {
            writer << json
        }
    }

    boolean isWriteAsSingleLine() {
        writeAsSingleLine == true
    }

    protected abstract Object buildJsonStructure(AnalysisContext analysisContext, Results results)

}
